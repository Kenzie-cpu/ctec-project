def s3(event, context):
    return "trigger"
